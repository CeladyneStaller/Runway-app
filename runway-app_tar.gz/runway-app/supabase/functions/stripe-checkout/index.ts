// Creates a Stripe Checkout Session for the signed-in user.
//
// Called from the browser with the user's Supabase JWT. The SECRET KEY never leaves this function.
// We do not build card fields: Checkout is hosted, which keeps this out of PCI scope entirely.
import { corsHeaders } from "../_shared/cors.js";
const STRIPE_SECRET = Deno.env.get("STRIPE_SECRET_KEY")!;
const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const ANON_KEY = Deno.env.get("SUPABASE_ANON_KEY")!;
const SITE_URL = Deno.env.get("SITE_URL") || "http://localhost:5173";

// PARSED DEFENSIVELY, like the webhook's `readPriceMap` — this was a bare `JSON.parse` and should
// never have been. A THROW AT MODULE SCOPE MEANS THE FUNCTION NEVER BOOTS, so every request fails,
// including the CORS preflight, and the browser reports a CORS error with nothing in the function
// logs. A JSON typo in a secret then presents as a deployment or CORS problem — three plausible
// causes for one symptom, distinguishable only by curling the endpoint by hand.
function readPriceIds(envName = "STRIPE_PRICE_IDS"): Record<string, string> {
  const raw = Deno.env.get(envName);
  if (!raw) return {};
  try {
    const parsed = JSON.parse(raw);
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("not an object");
    return parsed as Record<string, string>;
  } catch (e) {
    console.error(`[checkout] ${envName} is not valid JSON, ignoring it:`, (e as Error).message);
    console.error('[checkout] expected: {"solo":"price_123","advisor":"price_456"}');
    return {};
  }
}
const PRICE_MAP: Record<string, string> = readPriceIds();
// SEPARATE FROM THE COMPANY MAP, and that separation is what tells the webhook which TABLE a
// subscription belongs in. An advisor plan is keyed on the USER; a company plan on the company. One map
// carrying both would force the kind to be inferred from a plan NAME, and a rename later would quietly
// start writing to the wrong table.
const ADVISOR_PRICE_MAP: Record<string, string> = readPriceIds("STRIPE_ADVISOR_PRICE_IDS");

// ONE definition of the CORS rules, shared with the other browser-facing functions and unit-tested
// in `test/engine/cors.test.js`. Hand-writing this header set per function is what produced three
// different CORS failures in a row, each a separate omission from a separate literal.
const cors = corsHeaders(SITE_URL, [SITE_URL]);

/** Who is calling? Verified against Supabase Auth rather than trusted from the request body — a
 *  user_id in a POST is a claim, not an identity, and this one decides who gets billed. */
async function callerId(req: Request): Promise<string | null> {
  const jwt = req.headers.get("Authorization")?.replace(/^Bearer /, "");
  if (!jwt) return null;
  const r = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    headers: { apikey: ANON_KEY, Authorization: `Bearer ${jwt}` },
  });
  if (!r.ok) return null;
  return (await r.json())?.id ?? null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: cors });

  const userId = await callerId(req);
  if (!userId) return new Response("unauthorized", { status: 401, headers: cors });

  const { plan, company_id: companyId, kind = "company", cadence: rawCadence } =
    await req.json().catch(() => ({}));

  // Unix seconds, or null when there is no trial left to honour. Declared here so the advisor branch —
  // which has no company and therefore no company trial — simply leaves it null.
  let trialEnd: number | null = null;
  const advisor = kind === "advisor";

  // AN ADVISOR PLAN IS BOUGHT FOR YOURSELF, so there is no company and nothing to be permitted to do:
  // the caller's identity, already verified above, IS the authorisation. A company plan is bought for
  // somebody else's benefit and needs the check below.
  if (!advisor) {
    if (!companyId) return new Response("company_required", { status: 400, headers: cors });

    // ONLY SOMEBODY WHO COULD USE IT MAY BUY IT. Without this check anyone could open a Checkout
    // session against any company id and pay for a stranger's subscription — harmless to them and
    // confusing forever afterwards, since the webhook would attach it and nobody would know why.
    const allowed = await fetch(`${SUPABASE_URL}/rest/v1/rpc/can_edit`, {
      method: "POST",
      headers: { apikey: ANON_KEY, Authorization: req.headers.get("Authorization")!,
                 "Content-Type": "application/json" },
      body: JSON.stringify({ c: companyId }),
    });
    if (!allowed.ok || (await allowed.json()) !== true) {
      return new Response("forbidden", { status: 403, headers: cors });
    }

    // ⚠️ THE TRIAL DOES NOT END AT CHECKOUT, AND NOTHING EVER CLEARED IT. `company_entitled` is an OR
    // — `s.current_period_end > now() OR c.trial_ends_at > now()` — so somebody who subscribes on day
    // three is entitled for the remaining eleven days whether or not they pay.
    //
    // **Without a `trial_end`, Stripe bills immediately and the customer pays for days they already
    // had.** On monthly that is a rounding error; on yearly Collaborative it is $1,188 charged today
    // with eleven days of it already free.
    //
    // Handing Stripe the date the app already knows makes the paid period start where the free one
    // stops. The customer is entitled throughout either way — this only decides who pays for the gap.
    const row = await fetch(
      `${SUPABASE_URL}/rest/v1/companies?id=eq.${companyId}&select=trial_ends_at`,
      { headers: { apikey: ANON_KEY, Authorization: req.headers.get("Authorization")!,
                   Accept: "application/json" } });
    if (row.ok) {
      const [company] = await row.json().catch(() => []);
      const ends = company?.trial_ends_at ? Date.parse(company.trial_ends_at) : NaN;
      // Only when it is genuinely in the future. A past date would make Stripe reject the session,
      // and an absent one means this company has no trial to preserve.
      if (Number.isFinite(ends) && ends > Date.now()) {
        trialEnd = Math.floor(ends / 1000);
      }
    }
  }

  const priceMap = advisor ? ADVISOR_PRICE_MAP : PRICE_MAP;
  // Told apart on purpose. An EMPTY map is a deployment that was never finished; a missing KEY is a
  // plan this deployment does not sell. Reporting both as "unknown plan" sends you to look at the
  // client for a server-side omission.
  if (Object.keys(priceMap).length === 0) {
    console.error(`[checkout] ${advisor ? "STRIPE_ADVISOR_PRICE_IDS" : "STRIPE_PRICE_IDS"} is unset ` +
                  "or empty — no plan can be priced");
    return new Response("not_configured", { status: 500, headers: cors });
  }
  // ⚠️ THE MAP IS KEYED ON THE PAIR NOW: `{"solo:yearly":"price_1","solo:monthly":"price_2"}`.
  //
  // **Bare `plan` keys still work and mean yearly**, which is what every existing deployment has — so
  // this ships without a flag day and an env that has not been updated keeps selling exactly what it
  // sold yesterday.
  //
  // An unknown PAIR fails the same way an unknown plan already did, rather than falling back to the
  // other cadence: **charging somebody yearly because the monthly price id was missing is the worst
  // available failure**, and silent fallbacks are how it would happen.
  const cadence = rawCadence === "monthly" ? "monthly" : "yearly";
  const price = priceMap[`${plan}:${cadence}`]
    ?? (cadence === "yearly" ? priceMap[plan] : undefined);
  if (!price) {
    console.error(`[checkout] no price for ${plan}:${cadence} —`,
      `known keys: ${Object.keys(priceMap).join(", ") || "(none)"}`);
    return new Response("unknown plan", { status: 400, headers: cors });
  }

  const form = new URLSearchParams({
    mode: "subscription",
    "line_items[0][price]": price,
    "line_items[0][quantity]": "1",
    success_url: `${SITE_URL}/#account?checkout=success`,
    cancel_url: `${SITE_URL}/#account?checkout=cancelled`,
    // BOTH, deliberately. `client_reference_id` identifies the session; the metadata is copied onto
    // the SUBSCRIPTION, so later lifecycle events — which never mention the session — can still be
    // attributed. Without it, a renewal three months from now is unattributable.
    //
    // THE COMPANY IS WHAT A SUBSCRIPTION BELONGS TO now, so that is what the session and the
    // subscription are both stamped with. `user_id` rides along as WHO PAID, which the billing portal
    // still needs because a Stripe customer is a person rather than a company.
    // An advisor plan has no company, so the USER is what it is stamped with. The webhook routes on
    // which price map holds the price rather than on what is here — metadata says WHO, the maps say
    // WHAT KIND, and neither has to guess at the other.
    client_reference_id: advisor ? userId : companyId,
    ...(advisor ? {} : { "subscription_data[metadata][company_id]": companyId }),
    "subscription_data[metadata][user_id]": userId,
    // ⚠️ ONLY WHEN THERE IS ONE. Sending an empty value here makes Stripe reject the session, so the
    // key is omitted entirely rather than sent blank.
    ...(trialEnd ? { "subscription_data[trial_end]": String(trialEnd) } : {}),
    // Lets Checkout collect a billing address, which Stripe Tax needs if it is ever switched on.
    billing_address_collection: "auto",
    allow_promotion_codes: "true",
  });

  const r = await fetch("https://api.stripe.com/v1/checkout/sessions", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${STRIPE_SECRET}`,
      "Content-Type": "application/x-www-form-urlencoded",
      // Idempotency: a double-clicked button must not create two sessions.
      "Idempotency-Key": `checkout:${userId}:${plan}:${Math.floor(Date.now() / 60000)}`,
    },
    body: form,
  });

  if (!r.ok) {
    console.error("[stripe] checkout failed", await r.text());
    return new Response("checkout_failed", { status: 502, headers: cors });
  }
  const session = await r.json();
  return new Response(JSON.stringify({ url: session.url }), {
    headers: { ...cors, "Content-Type": "application/json" },
  });
});
