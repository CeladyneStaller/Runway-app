// Where an advisor lands.
//
// AN ADVISOR'S HOME IS THE PORTFOLIO, NOT A COMPANY. Everybody else signs in to one model; an advisor
// signs in to a list of them, and the question they open the app with is "who do I call today" — which
// is why the rail is their client list and the landing is sorted by who runs out first.
//
// EVERY CLIENT'S MODEL IS LOADED IN FULL. That is not laziness avoided, it is required: the runway is
// computed from the document by the same function the dashboard uses, so no client can show one number
// here and another there. The tiles are then free.
//
// Loading is PROGRESSIVE and per-company. Twenty models is twenty round trips, and a screen that waits
// for the slowest one is a screen that looks broken for the nineteen that already arrived.
import React, { useEffect, useMemo, useState } from "react";
import mark from "../../assets/waterline-mark.svg";
import { money } from "../../engine/money";
import { runwayMonths } from "./docsummary";
import { buildModelParts, buildModelFromDoc } from "../../engine/buildmodel";
import { buildProjection , zeroInfo} from "../../engine/projection";
import { alertsFor } from "../../engine/alerts";
import { AdvisorCompany } from "./AdvisorCompany";
import { ProfileMenu } from "./ProfileMenu";

/** Above this many clients the rail stops listing them all and shows only what needs attention.
 *  A rail with twenty entries is a scrollbar, which is not navigation. */
const RAIL_MAX = 8;

const clean = (n) => (Number.isFinite(n) ? n : null);

function useClients(account) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      let list = [];
      try { list = (await account?.listAdvisedCompanies?.()) || []; }
      catch (e) { if (alive) { setErr(e?.message || "Could not list your clients."); setLoading(false); } return; }

      if (!alive) return;
      setRows(list.map(c => ({ ...c, state: "loading" })));
      setLoading(false);

      // One at a time, updating as each arrives. A client whose model fails is marked, NOT dropped —
      // silently omitting it would tell an advisor they have fewer clients than they do.
      for (const c of list) {
        // ON THE ACCOUNT API, not a module export — `Portfolio` already reads it this way, and it goes
        // through `load_document` plus `assembleFromStorage` because the blob no longer carries
        // projects. Reading the table directly was a silent wrong-runway bug once already.
        let doc = null, failed = null;
        if (c.has_document === false) {
          failed = null;                       // an empty company is not a broken one
        } else {
          try { doc = await account.readCompanyDocument(c.id); }
          catch (e) { failed = e?.message || "Could not read this model."; }
        }
        if (!alive) return;

        let parts = null, months = null, floorMonths = null, cash = null, attention = 0;
        if (doc) {
          try {
            parts = buildModelParts(doc);
            const rows2 = buildProjection(buildModelFromDoc(doc), doc.settings?.toggles || {});
            parts = { ...parts, rows: rows2 };
            // ⚠️ TWO RUNWAYS, NOT ONE. A single figure cannot answer an advisor's actual question,
            // which is not "how long" but **"how much of this depends on money nobody has promised?"**
            //
            // The FLOOR counts committed AND expected income — everything except what the company is
            // still chasing. The HEADLINE counts everything, speculative included.
            //
            // ⚠️ NONE OF THE FOUR DEMO COMPANIES DIFFER ON THIS PAIR, so the second line will not
            // render for any of them today. That is a fact about the sample data rather than about the
            // measure: **a real client pursuing a large unwon grant is exactly the case it exists for**,
            // and Ridgeline's Phase III proposal does not move its FIRST crossing because the money
            // arrives in month 18, after cash has already run out.
            //
            // **The gap between them IS the finding.** A client at 5 and 11 has a fundable plan and a
            // deadline; a client at 5 and 5 has neither, and those two look identical on one number.
            const model = buildModelFromDoc(doc);
            const runwayAt = (toggles) => {
              const z = zeroInfo(buildProjection(model, toggles), doc.startY, doc.startM);
              return z ? clean(z.months) : null;      // null means it does not run out in the horizon
            };
            floorMonths = runwayAt({ committed: true, expected: true, speculative: false });
            months = runwayAt(doc.settings?.toggles || { committed: true, expected: true, speculative: true });
            cash = clean(doc.cash);
            // ⚠️ THE WORST THING, NAMED — NOT A COUNT OF EVERYTHING.
            //
            // Counting all alerts across all tabs gave every company 4, because the same alert appears
            // on several tabs and most of them are `info` — "no spend history yet" is true of every new
            // company and needs no advisor. **A number that is the same for everybody sorts nobody**,
            // which is what a portfolio column is for.
            //
            // So: drop `info`, de-duplicate by id, and show the text of the most severe remaining one.
            // An advisor scanning this wants to know WHAT is wrong, and a count cannot tell them.
            const seen = new Map();
            for (const tab of ["dash", "flow", "pay", "proj", "sales", "inv", "cmt", "hist"]) {
              for (const al of alertsFor(tab, doc, parts) || []) {
                if (al.tone === "info") continue;
                if (!seen.has(al.id)) seen.set(al.id, al);
              }
            }
            const worst = [...seen.values()]
              .sort((x, y) => (y.tone === "bad" ? 1 : 0) - (x.tone === "bad" ? 1 : 0))[0];
            attention = worst
              ? { text: worst.text, tone: worst.tone, more: seen.size - 1 }
              : null;
          } catch (e) { failed = e?.message || "This model could not be read."; doc = null; }
        }
        setRows(prev => prev.map(r => (r.id === c.id
          ? { ...r, doc, parts, months, floorMonths, cash, attention, failed,
              state: failed ? "failed" : "ready" }
          : r)));
      }
    })();
    return () => { alive = false; };
  }, [account]);

  return { rows, loading, err };
}

const toneOf = (m) => (m == null ? "" : m < 6 ? "bad" : m < 12 ? "warn" : "");

function Portfolio({ rows, onOpen }) {
  const ready = rows.filter(r => r.state === "ready");
  const pending = rows.filter(r => r.state === "loading").length;
  // ⚠️ JUDGED ON THE FLOOR, NOT THE HEADLINE. A client at six months on paper and three months on
  // committed income is in trouble now — **counting the optimistic figure is how an advisor finds out
  // late**, which is the failure this whole view exists to prevent.
  const short = ready.filter(r => (r.floorMonths ?? r.months) != null
                                  && (r.floorMonths ?? r.months) < 6);
  const shortest = ready.reduce((a, r) => (r.months != null && (a == null || r.months < a) ? r.months : a), null);
  // ⚠️ CLIENTS NEEDING ATTENTION, NOT ALERTS TOTALLED. `r.attention` became an object when the column
  // started naming the worst finding instead of counting everything — and `0 + {}` is the string
  // "0[object Object]" rather than an error, so it rendered.
  //
  // Counting CLIENTS is also the right number: **an advisor's morning question is how many people to
  // call, not how many findings exist across them.** Three problems at one client is still one call.
  const attention = ready.filter(r => r.attention).length;

  // WHO RUNS OUT FIRST, which is the order that answers the question an advisor opened the app with.
  // A client still loading sorts last rather than to the top: an unknown runway is not an urgent one.
  const sorted = [...rows].sort((a, b) => {
    if (a.months == null && b.months == null) return 0;
    if (a.months == null) return 1;
    if (b.months == null) return -1;
    return a.months - b.months;
  });

  return (
    <>
      <div className="stats">
        <div className="stat">
          <div className="lab">Clients</div><div className="big">{rows.length}</div>
          <div className="meta">{pending ? `${pending} still loading` : "all loaded"}</div>
        </div>
        <div className="stat">
          <div className="lab">Under 6 months</div>
          <div className="big" style={short.length ? { color: "var(--danger)" } : null}>{short.length}</div>
          <div className="meta">{short.length ? short.map(r => r.name).slice(0, 2).join(", ") : "none"}</div>
        </div>
        <div className="stat">
          <div className="lab">Need attention</div><div className="big">{attention}</div>
          <div className="meta">across your clients</div>
        </div>
        <div className="stat hero">
          <div className="lab">Shortest runway</div>
          <div className="big">{shortest == null ? "—" : `${shortest.toFixed(1)} mo`}</div>
          <div className="meta">of those loaded</div>
        </div>
      </div>

      <section className="panel">
        <div className="panel-h">
          <div>
            <h3>Your clients</h3>
            <p>Sorted by who runs out first. Every figure is computed from that client's own model.</p>
          </div>
        </div>
        <table className="tbl">
          <thead>
            <tr><th>Company</th><th style={{ textAlign: "right" }}>Runway<span className="th-sub">with / without speculative</span></th>
              <th style={{ textAlign: "right" }}>Cash</th><th>Attention</th><th></th></tr>
          </thead>
          <tbody>
            {sorted.map(r => (
              <tr key={r.id}>
                <td><b>{r.name}</b></td>
                <td style={{ textAlign: "right", fontFamily: "var(--fm)",
                             color: r.months != null && r.months < 6 ? "var(--danger)" : undefined }}>
                  {r.state === "loading" ? "…"
                    : r.state === "failed" ? "—"
                    : r.months == null ? "positive" : `${r.months.toFixed(1)} mo`}
                  {/* ⚠️ THE FLOOR SITS UNDER THE HEADLINE FIGURE, and only when it differs. Printing
                      "5.4 committed" beneath 5.4 is noise; printing it beneath 10.7 is the finding —
                      **that client's runway is half real and half hoped for.** */}
                  {r.state === "ready" && r.floorMonths != null
                    && (r.months == null || Math.abs(r.floorMonths - r.months) >= 0.1) && (
                    <span className="rw-floor">
                      {r.floorMonths.toFixed(1)} without speculative
                    </span>
                  )}
                </td>
                <td style={{ textAlign: "right", fontFamily: "var(--fm)" }}>
                  {r.cash == null ? "" : money(r.cash)}
                </td>
                <td>
                  {/* A MODEL THAT WOULD NOT LOAD SAYS SO IN THE ROW. Leaving it blank would read as a
                      client with nothing wrong, which is the one thing it definitely is not. */}
                  {r.state === "failed"
                    ? <span className="chip bad">could not read</span>
                    : r.attention
                      ? (<span className={"chip " + (r.attention.tone === "bad" ? "bad" : "warn")}
                               title={r.attention.text}>
                           {r.attention.text}
                           {r.attention.more > 0 && <b> +{r.attention.more}</b>}
                         </span>)
                    // ⚠️ "ON PLAN" RATHER THAN A DASH. A dash reads as "not checked"; this row HAS been
                    // checked and found nothing, which is the single most reassuring thing a portfolio
                    // can tell an advisor.
                    : r.state === "ready" ? <span className="chip ok">On plan</span> : null}
                </td>
                <td><button className="linkbtn" onClick={() => onOpen(r.id)}>Open →</button></td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </>
  );
}

export function AdvisorHome({ account, onEnterCompany, onOpenSettings, banner = null,
                             onFeedback = null }) {
  const { rows, loading, err } = useClients(account);
  const [at, setAt] = useState("portfolio");        // "portfolio" | a company id

  const here = rows.find(r => r.id === at) || null;

  // Only what needs attention, once the list is long enough that a rail cannot hold it.
  const railRows = useMemo(() => {
    if (rows.length <= RAIL_MAX) return rows;
    return [...rows]
      .filter(r => r.months != null && r.months < 12)
      .sort((a, b) => a.months - b.months)
      .slice(0, RAIL_MAX);
  }, [rows]);

  const trimmed = rows.length > RAIL_MAX;

  return (
    // `.rw` SCOPES THE ENTIRE STYLESHEET. Every other screen wraps in it — `RunwayApp`, `Account`, the
    // sign-in — and without it this rendered as unstyled HTML: correct structure, no character at all.
    // Nothing failed, which is why it looked like a broken page rather than a missing class.
    <div className="rw">
    <div className="shell">
      <aside className="rail">
        {/* THE MARK, which I dropped when fixing the invented `brandmark` class — I replaced the
            element with text and left the image out, so the rail kept its words and lost its logo. */}
        <div className="brand">
          <img src={mark} alt="Waterline" width={100} />
          <div><b>Waterline</b><span>runway control</span></div>
        </div>

        <div className="railmeta railgrp">Advising{rows.length ? ` · ${rows.length}` : ""}</div>
        {/* NO WRAPPER. `.nav` is the BUTTON class here — App puts them straight in the rail — and a
            container sharing the class matched every selector first, including the tests' clicks. */}
        <button className={"nav" + (at === "portfolio" ? " on" : "")}
                  onClick={() => setAt("portfolio")}>
          Portfolio<span className="navr">{rows.length || ""}</span>
        </button>

        {railRows.length > 0 && (
          <>
            <div className="railmeta railgrp">{trimmed ? "Needs attention" : "Clients"}</div>
            {railRows.map(r => (
                <button key={r.id} className={"nav" + (at === r.id ? " on" : "")}
                        onClick={() => setAt(r.id)}>
                  <span className="navname">{r.name}</span>
                  <span className={"navr " + toneOf(r.months)}>
                    {r.state === "loading" ? "…" : r.months == null ? "" : r.months.toFixed(1)}
                  </span>
                </button>
            ))}
          </>
        )}

        <div className="railfoot">
          {/* ⚠️ THE ADVISOR VIEW HAS A RAIL AND I DID NOT LOOK — I put this in the topbar on the
              assumption it had none. Same component, same class, same place as the company views, so
              somebody moving between the two finds it where they left it. */}
          {onFeedback && (
            <button className="nav navset railset" onClick={onFeedback}>
              <span aria-hidden="true">✉</span>
              <span className="railset-t">Send feedback</span>
            </button>
          )}
          <div className="railmeta">
            {trimmed
              ? `${rows.length - railRows.length} more in your portfolio`
              : "Your clients, by runway"}
          </div>
        </div>
      </aside>

      <main className="main">
        <div className="topbar">
          <div>
            {/* ⚠️ THE BANNER BELONGS BESIDE THE LABEL IT QUALIFIES, not on a row of its own above
                the page. "Advisor" and "Advisor demo" answer the same question — what am I looking at —
                and separating them makes the second look like a system message rather than an
                adjective on the first. */}
            <span className="eyebrow-row">
              <span className="eyebrow">{here ? "Advising · read only" : "Advisor"}</span>
              {banner}
            </span>
            <h1 className="h1">{here ? here.name : "Your portfolio"}</h1>
          </div>
          {/* THE AVATAR IS ON EVERY SCREEN OR IT IS ON NONE. It was in the company app's header and
              missing here — so an advisor, whose home this is, had no route to their own settings
              without first opening a client. The one thing that follows a person across companies was
              reachable only from inside one. */}
          <div className="topright">
            {here && (
              // A BUTTON NAMING THE COMPANY, not a switcher. Switching is what you do to change
              // context; this is what you do to one company you are already looking at.
              <button className="addbtn" onClick={() => onEnterCompany(here.id, "dash")}>
                Open {here.name} →
              </button>
            )}
            {/* ⚠️ NO PROFILE IN THE DEMO. There is no account behind it — every item in that menu
                either does nothing or offers to change settings for a person who does not exist. */}
            {!banner && <ProfileMenu onGo={(page) => onOpenSettings?.("profile", page)} />}
          </div>
        </div>

        {err && <div className="signin-error" role="alert">{err}</div>}
        {loading && <p className="acct-row-s">Loading your clients…</p>}

        {!loading && rows.length === 0 && !err && (
          <section className="panel">
            <div className="panel-h">
              <div>
                <h3>No clients yet</h3>
                <p>
                  A company owner invites you, and it appears here. You hold no seat in their
                  subscription and cannot change their model.
                </p>
              </div>
            </div>
          </section>
        )}

        {at === "portfolio" && rows.length > 0 && (
          <Portfolio rows={rows} onOpen={(id) => setAt(id)} />
        )}

        {here && (
          here.state === "loading"
            ? <p className="acct-row-s">Loading {here.name}…</p>
            : <AdvisorCompany
                account={account}
                company={here} doc={here.doc} parts={here.parts}
                hiddenTabs={here.hiddenTabs || []}
                onOpen={(view) => onEnterCompany(here.id, view)} />
        )}
      </main>
    </div>
    </div>
  );
}
