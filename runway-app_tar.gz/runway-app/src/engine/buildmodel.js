// Assemble the projection MODEL from a document — the same pipeline App uses inline, extracted so a
// scenario's modified document runs through identical logic. This is the seam that makes scenarios
// trustworthy: base-doc-in -> the exact model App would build, so a scenario differs from base only by
// its patches, never by a divergent code path.
//
// Kept in the engine (pure, no React). App can adopt this later to de-duplicate; for now Scenarios
// uses it and a test pins that it reproduces App's base projection.

import { HORIZON } from "./time.js";
import { compileEmployee, empCostAt, empMonthlyOf, empSalaryAt } from "./payroll.js";
import { resolveFringeRate } from "./fringe.js";
import { compileProject, resolveProjectRates, syncFulfilStage, compileInternalLabor } from "./projects.js";
import { compilePO } from "./sales.js";
import { compileInstrument } from "./capital.js";
import { compileSaas, saasVariances } from "./saas.js";
import { indexedLines } from "./commitments.js";
import { tagRevenue } from "./projection.js";
import { applyRevenueActuals } from "./revenue.js";
import { codedRevenue } from "./coding.js";
import { burnStats } from "./history.js";

// The full assembly, returning the model AND the intermediate pieces the UI needs (payroll lines for
// the Payroll view, resolved projects for the Projects view, the burn figures for Spend history, and
// so on). App used to recompute every one of these inline, giving the app two parallel assemblies of
// the same thing pinned together by a single golden assertion. They were verified identical across 272
// document x toggle combinations before being merged — but "identical today" is not a guarantee, and
// the band-alignment bug already showed what divergence costs.
export function buildModelParts(doc, horizon = HORIZON) {
  const employees = doc.employees || [];
  const projects = doc.projects || [];
  const pos = doc.pos || [];
  const rounds = doc.rounds || [];
  const saas = doc.saas || [];
  const lines = doc.lines || [];
  const hist = doc.history || [];
  const codeMap = doc.codeMap || {};
  const customerMap = doc.customerMap || {};
  const toggles = doc.settings?.toggles || {};
  const flagOverrides = doc.flagOverrides || doc.settings?.flagOverrides || {};
  const method = doc.settings?.method || "trailing";
  const applyBaseline = doc.settings?.applyBaseline !== false;

  // fringe (itemized/manual -> resolved %), matching App
  const avgSalary = employees.length
    ? (employees.reduce((a, e) => a + empCostAt(e, 0, 0), 0) / employees.length) * 12 : 0;
  // empCostAt with fr=0 gives salary-only; average annual salary base for insurance-as-% in fringe calc
  const fringePct = resolveFringeRate(doc.settings?.fringe || {}, avgSalary, doc.settings?.fringePct ?? 0.30);

  const employeeLines = employees.flatMap(e => compileEmployee(e, fringePct));
  const rProjects = syncFulfilStage(resolveProjectRates(projects, employees, fringePct), pos);
  const projectLines = rProjects.flatMap(p => {
    if (p.stage === "prospective" && !p.include) return [];
    // ⚠️ INTERNAL LABOR JOINS HERE, NOT IN `employeeLines`. It is a PROJECT cost that happens to be
    // paid to a person — putting it with the employees would double-count anybody already drawing a
    // salary, because `compileEmployee` has already emitted their full pay.
    //
    // The salary is resolved with the SAME helpers Payroll uses. A second resolution would give two
    // answers for one salary the first time a raise landed.
    // ⚠️ ZERO-COST LINES. `compileEmployee` ALREADY CHARGES DANA'S FULL SALARY in `employeeLines` —
    // she is paid whether or not she is assigned to a project. Pricing this line too charged her twice
    // and overstated burn by the allocated share.
    //
    // **Internal labor ATTRIBUTES an existing cost; it does not add one.** The line carries the
    // employee, the project and the share so allocation and the project's own cost can read it, and
    // `amount: 0` so the projection does not.
    //
    // `laborAmount` is what the CARD shows — the cost of that person's time — and is deliberately not
    // the same field, because one is an attribution and the other is a charge.
    const labor = compileInternalLabor(p, employees, doc).map(l => {
      const e = employees.find(x => x.id === l.employeeId);
      const monthly = e ? empMonthlyOf(e, empSalaryAt(e, Math.max(0, l.start || 0))) : 0;
      const perDay = l.workingDays > 0 ? (monthly * 12) / l.workingDays : 0;
      return { ...l, amount: 0, laborAmount: perDay * l.daysPerMonth };
    });
    return [...compileProject(p), ...labor]
      .map(l => ({ ...l, projectId: p.id, projectName: p.name }));
  });

  // baseline burn (anchors opex forward to the historical run-rate)
  const payrollNow = employees.reduce((a, e) => a + empCostAt(e, 0, fringePct), 0);
  // ⚠️ AN ADJUSTMENT IS NOT AN ITEMISED COST, and excluding it is the whole reason this works.
  //
  // The baseline is measured burn MINUS what you have itemised. A -$5,000 overhead adjustment counted
  // as itemisation would shrink `itemizedOpex` by $5,000, grow `baselineOpex` by exactly $5,000, and
  // CANCEL ITSELF — the runway would not move and nothing on screen would say why. It still spends in
  // the projection; it just must not feed the subtraction it is trying to reduce.
  const companyOpexNow = lines.filter(l => l.kind === "cost" && !l.adjustment && l.cadence === "recurring" && (l.start || 0) <= 0 && (l.end == null || l.end >= 0))
    .reduce((a, l) => a + (Number(l.amount) || 0), 0);
  const itemizedOpex = companyOpexNow + payrollNow;
  const derivedBurn = burnStats(hist, itemizedOpex, flagOverrides, method).applied;
  const baselineOpex = applyBaseline ? Math.max(0, derivedBurn - itemizedOpex) : 0;
  const baselineLines = baselineOpex > 0.5
    ? [{ label: "Other operating costs (baseline)", cadence: "recurring", kind: "cost", amount: baselineOpex, start: 0, end: null }]
    : [];

  const salesLines = pos.flatMap(po => compilePO(po).map(l => ({ ...l, poId: po.id })));
  const roundLines = rounds.flatMap(x => compileInstrument(x, rounds));
  // Subscription books expand to ordinary revenue lines here, before anything downstream sees them.
  const saasLines = saas.flatMap(x => compileSaas(x, horizon));

  // revenue replacement (Piece 3): recorded revenue replaces projected for each project's past
  const revActuals = {};
  for (const p of rProjects) {
    const r = codedRevenue(p.id, hist, { codeMap, customerMap });
    if (Object.keys(r).length) revActuals[p.id] = r;
  }
  const poProject = Object.fromEntries(pos.filter(p => p.projectId).map(p => [p.id, p.projectId]));

  const rawLines = tagRevenue([...lines, ...employeeLines, ...projectLines, ...salesLines, ...roundLines, ...saasLines, ...baselineLines]);
  const { lineItems: baseItems, variances } = applyRevenueActuals(rawLines, revActuals, toggles, { poProject });
  // INDEXED COMMITMENTS LAST, and measured against everything else. They scale with revenue, project
  // spend or profit, so they cannot be built alongside the lines they measure — and they must not
  // measure against themselves, which is why they are appended rather than folded in.
  const lineItems = [...baseItems, ...indexedLines(doc, baseItems, horizon)];
  // Subscription variances join the project ones in a SINGLE list, so the "recorded revenue differs
  // from projection" panel stays one place to look rather than two. They carry `label` because they
  // have no project to resolve a name from.
  const allVariances = [...variances, ...saas.flatMap(x => saasVariances(x, horizon))];

  return {
    model: { cashOnHand: doc.cash || 0, horizon, lineItems },
    // intermediates, so the UI can render the pieces without rebuilding them from scratch
    avgSalary, fringePct,
    employeeLines, rProjects, projectLines, salesLines, roundLines, saasLines, baselineLines,
    payrollNow, companyOpexNow, itemizedOpex, derivedBurn, baselineOpex,
    revenueVariances: allVariances,
  };
}

// The model alone — what scenarios, bands and labor prioritization consume.
export function buildModelFromDoc(doc, horizon = HORIZON) {
  return buildModelParts(doc, horizon).model;
}
