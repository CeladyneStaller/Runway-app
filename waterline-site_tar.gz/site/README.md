# Waterline — website

Static HTML. No build step, no framework, no dependencies. Drop the folder on Vercel, Netlify or
anything that serves files.

## Structure

    /                        home
    /product/                overview
    /product/grants/         the page nobody else can write
    /product/commitments/    signed vs spent, covered runway
    /product/scenarios/      the three confidence layers
    /advisors/               its own page, its own pricing
    /pricing/                the app's real figures, plus the FAQ
    /security/               the page that unblocks the first real customer
    /privacy/  /terms/       plain-language drafts, NOT lawyer-reviewed
    /docs/                   help, written as questions arrive
    /docs/quickbooks/        what is read, and what unpaid bills miss
    /writing/                six named pieces, one written
    /writing/reimbursement-lag/

    shared.css               one stylesheet
    mark.svg                 the duck, defined once, referenced by <use>
    _parts.py                the shell — regenerate pages after editing

## Prices come from the app

Solo $40 · Collaborative $99 · Connected $149 · Advisor $99 · Advisor Unlimited $199 · 14-day trial.
Taken from `src/state/plans.js`. **If those change, this site is wrong** — there is no import, and a
site that contradicts checkout costs more than one that is out of date.

## Before it goes live

1. **Backups.** `/security/` says explicitly that retention is not yet described. Ship the backups,
   then replace that paragraph. Do not describe a policy that does not exist.
2. **Legal review** of `/privacy/` and `/terms/`. Both carry a visible notice saying they are drafts;
   remove it when reviewed.
3. **A real inbox** at info@waterline-runway.com. The address appears on nine pages.
4. **The five unwritten articles.** They are listed as "Coming" rather than linked, so nothing is
   broken — but a list that stays unwritten for six months should be trimmed to the one that exists.

## Domains

    waterline-runway.com          the site
    app.waterline-runway.com      the app

The site links to `app.waterline-runway.com`. **It 404s until the DNS record answers** — which is
correct, because the site is not public until then either. Both go live together.

See GO-LIVE-waterline-runway.md for the ordered checklist. Note in particular that **Intuit needs no
change**: `QBO_REDIRECT_URI` points at Supabase, not at the app.

## Editing

**The HTML files are the source.** `_parts.py` documents the shared shell — nav, footer, head tags —
but it is NOT a working generator: the page bodies were written through it and not kept, so re-running
it would produce empty pages.

That is a flaw in how this was built, and it has one practical consequence: **a change to the nav or
footer has to be made in fourteen files.** Use a script, not fourteen edits:

    python3 - <<'EOF'
    import glob
    for f in glob.glob("**/*.html", recursive=True):
        s = open(f).read()
        s = s.replace("OLD", "NEW")
        open(f, "w").write(s)
    EOF

If the shell starts changing often, that is the signal to move to a real static-site generator — not
before.

## The legal pages are generated, not hand-edited

`python3 build_legal.py` regenerates `/terms/` and `/privacy/` from
`../../rw/src/legal/{terms,privacy}.md` — **the same markdown the app's modal renders.**

⚠️ **Do not edit `terms/index.html` or `privacy/index.html` directly.** Two hand-maintained copies is
how a site says one thing and an app says another, and the difference only surfaces when somebody quotes
the wrong one back at you. Edit the markdown, bump `VERSION` in both `build_legal.py` and
`src/legal/index.js`, and regenerate.

⚠️ **The placeholders these replaced were 5KB for a 39KB document** — a page headed "Terms." with a
paragraph under it. That is worse than no page: procurement finds it, reads it, and concludes there are
no real terms.

⚠️ **All-caps paragraphs keep their capitals and get `class="caps"`.** Several disclaimers are only
enforceable if they are conspicuous; sentence-casing them for tidiness weakens the clause.

**Superseded versions must stay reachable.** An acceptance record naming a version points at a document
that has to still exist — when the text changes, the old build goes to `/terms/<version>/` rather than
being overwritten.

## SEO

⚠️ `head(title, desc, current, path)` — `current` HIGHLIGHTS A NAV ITEM, `path` IS THE PAGE'S OWN URL.
They are not the same job. One variable did both for a long time, so every sub-page that passed
`current="/product/"` to light up the Product tab ALSO declared `/product/` as its canonical — a request
to be dropped from the index. Four content pages and both legal pages were asking not to be found.
`page()` now derives the URL from where the file is written, so a new sub-page cannot repeat it by
forgetting an argument.

    robots.txt      allows everything except the dated legal archives
    sitemap.xml     regenerate when pages are added — see the snippet in this repo's history
    og.png          1200x630. ⚠️ `og:image` POINTED AT A .PNG THAT DID NOT EXIST while only og.svg was
                    committed, so every shared link showed a blank card. SVG would not have rendered
                    either — LinkedIn, X and Slack do not accept it.
    JSON-LD         Organization on /, SoftwareApplication on /product/, Article on the essay.
                    Schema DESCRIBES the page; it never asserts anything a reader cannot find there.

Dated legal archives carry `noindex,follow`: byte-identical to the live versions, so they would compete
with them, but their links should still pass.
